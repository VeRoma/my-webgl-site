'use client'

import dynamic from 'next/dynamic'

import { IntroOverlay } from './components/IntroOverlay'
import { IntroProvider } from './components/context/IntroContext'

// Отключаем SSR для сцены
const Scene = dynamic(() => import('./components/Scene'), {
  ssr: false,
})

export default function Home() {
  return (
    // ВАЖНО: bg-black делает фон черным, чтобы не было белого экрана при загрузке
    <main className="relative w-full h-screen overflow-hidden bg-black">
      <IntroProvider>
        {/* Сцена (слой 0) */}
        <div className="absolute inset-0 z-0">
          <Scene />
        </div>

        {/* Интро (слой 50) */}
        <IntroOverlay />
      </IntroProvider>
    </main>
  )
}